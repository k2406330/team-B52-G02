package application;

import controller.MenuController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Inventory;

public class MainApp extends Application {

    private final Inventory inventory = new Inventory();

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/view/menu.fxml"));

        Parent root = loader.load();

        MenuController controller = loader.getController();
        controller.setInventory(inventory);

        stage.setTitle("PearlMart - Main Menu");
        stage.setScene(new Scene(root));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
