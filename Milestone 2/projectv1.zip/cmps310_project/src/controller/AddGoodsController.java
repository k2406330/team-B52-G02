package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import model.Inventory;
import model.InventoryItem;
import model.InventoryMovement;
import model.MovementType;
import javafx.scene.control.Alert;
public class AddGoodsController {

    private Inventory inventory;
    private boolean checked = false;
    private boolean reviewed = false;

    @FXML private TextField codeField;
    @FXML private TextField nameField;
    @FXML private TextField priceField;
    @FXML private TextField manufacturerField;
    @FXML private TextField originField;
    @FXML private TextField commentsField;
    @FXML private TextField quantityField;
    @FXML private DatePicker expirationPicker;
    @FXML
    private Button mainMenuButton;

    @FXML private Label messageLabel;
    @FXML private Button confirmButton;

    public AddGoodsController() {
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
        checked = false;
        invalidateReview();
    }

    @FXML
    private void initialize() {
    	mainMenuButton.setDisable(true);
        confirmButton.setDisable(true);

        codeField.textProperty().addListener(
                (obs, oldValue, newValue) -> {
                    checked = false;
                    invalidateReview();
                });

        TextField[] fields = {
                nameField,
                priceField,
                manufacturerField,
                originField,
                commentsField,
                quantityField
        };

        for (TextField field : fields) {
            field.textProperty().addListener(
                    (obs, oldValue, newValue) -> invalidateReview());
        }

        expirationPicker.valueProperty().addListener(
                (obs, oldValue, newValue) -> invalidateReview());

        expirationPicker.setEditable(false);
    }

    private void invalidateReview() {
        reviewed = false;
        confirmButton.setDisable(true);
        messageLabel.setText("");
    }

    public InventoryItem lookup(String code) {
        if (inventory == null || code == null || code.isBlank()) {
            return null;
        }

        return inventory.find(code.trim());
    }

    @FXML
    private void handleCheckItem() {
        checked = false;
        invalidateReview();

        if (inventory == null) {
            messageLabel.setText("Inventory is not connected.");
            return;
        }

        String code = codeField.getText().trim();

        if (code.isEmpty()) {
            messageLabel.setText("Please enter an item identifier.");
            return;
        }

        InventoryItem item = lookup(code);

        if (item == null) {
            clearInformation();
            setInformationEditable(true);

            messageLabel.setText(
                    "Item is new. Please enter information.");
        } else {
            nameField.setText(item.getName());
            priceField.setText(
                    Double.toString(item.getSellingPrice()));
            manufacturerField.setText(item.getManufacturer());
            originField.setText(item.getPlaceOfOrigin());
            commentsField.setText(item.getComments());
            expirationPicker.setValue(item.getExpirationDate());

            quantityField.clear();
            setInformationEditable(false);

            messageLabel.setText(
                    "Item found. Please enter the quantity to add.");
        }

        checked = true;
    }

    @FXML
    private void handleReviewAddition() {
        invalidateReview();

        if (inventory == null) {
            messageLabel.setText("Inventory is not connected.");
            return;
        }

        if (!checked) {
            messageLabel.setText("Please click Check Item first.");
            return;
        }

        try {
            String code = codeField.getText().trim();

            int quantity = Integer.parseInt(
                    quantityField.getText().trim());
            if (quantity <= 0) {
                showError("Quantity must be greater than zero.");
                return;
            }

            double price = Double.parseDouble(
                    priceField.getText().trim());

            InventoryItem item = lookup(code);

            String error = validate(
                    item,
                    code,
                    quantity,
                    nameField.getText().trim(),
                    price,
                    manufacturerField.getText().trim(),
                    originField.getText().trim(),
                    expirationPicker.getValue(),
                    commentsField.getText().trim());

            if (error != null) {
                messageLabel.setText(error);// if any of the field have invalid data type 
                return;
            }

            reviewed = true;
            confirmButton.setDisable(false);
            messageLabel.setText("OK. Please confirm the addition.");

        } catch (NumberFormatException e) {
            messageLabel.setText(
                    "Enter a whole-number quantity and a valid price.");
        }
    }

    @FXML
    private void handleConfirmAddition() {
        if (!reviewed) {
            messageLabel.setText("Please review the addition first.");
            return;
        }

        try {
            boolean success = confirmAddition(
                    codeField.getText().trim(),
                    Integer.parseInt(quantityField.getText().trim()),
                    nameField.getText().trim(),
                    Double.parseDouble(priceField.getText().trim()),
                    manufacturerField.getText().trim(),
                    originField.getText().trim(),
                    expirationPicker.getValue(),
                    commentsField.getText().trim());

            invalidateReview();
            if (success) {
                checked = false;

                InventoryItem savedItem = lookup(codeField.getText());

                showAdditionResult(savedItem);
                messageLabel.setText("Item added or updated successfully.");

                mainMenuButton.setDisable(false);
            } else {
                messageLabel.setText(
                        "Addition failed. Check and review again.");
            }

        } catch (NumberFormatException e) {
            invalidateReview();
            messageLabel.setText("Invalid quantity or price.");
        }
    }

    public boolean confirmAddition(
            String code,
            int quantity,
            String name,
            double sellingPrice,
            String manufacturer,
            String origin,
            LocalDate expirationDate,
            String comments) {

        if (inventory == null) {
            return false;
        }

        InventoryItem item = lookup(code);

        String error = validate(
                item,
                code,
                quantity,
                name,
                sellingPrice,
                manufacturer,
                origin,
                expirationDate,
                comments);

        if (error != null) {
            return false;
        }

        if (item != null) {
            inventory.addStock(item, quantity);
        } else {
            InventoryItem newItem = new InventoryItem(
                    code.trim(),
                    code.trim(),
                    name.trim(),
                    sellingPrice,
                    quantity,
                    manufacturer.trim(),
                    origin.trim(),
                    normalize(comments),
                    expirationDate);

            inventory.add(newItem);

            InventoryMovement movement = new InventoryMovement(
                    UUID.randomUUID().toString(),
                    MovementType.ADDED,
                    quantity,
                    LocalDateTime.now(),
                    newItem);

            inventory.addMovement(movement);
        }

        return true;
    }

    private String validate(
            InventoryItem currentItem,
            String code,
            int quantity,
            String name,
            double price,
            String manufacturer,
            String origin,
            LocalDate expirationDate,
            String comments) {

        if (code == null || code.isBlank()) {
            return "Please enter an item identifier.";
        }

        if (quantity <= 0) {
            return "Quantity must be greater than zero.";
        }

        if (name == null || name.isBlank()
                || manufacturer == null || manufacturer.isBlank()
                || origin == null || origin.isBlank()) {

            return "Please complete the required information.";
        }

        if (!Double.isFinite(price) || price <= 0) {
            return "Selling price must be greater than zero.";
        }

        if (expirationDate != null
                && !expirationDate.isAfter(LocalDate.now())) {

            return "Expiration date must be after today.";
        }

        if (currentItem != null
                && quantity > Integer.MAX_VALUE
                - currentItem.getQuantity()) {

            return "The resulting stock quantity is too large.";
        }

        for (InventoryItem other :
                inventory.searchByName(name.trim())) {

            if (other == currentItem) {
                continue;
            }

            if (Double.compare(other.getSellingPrice(), price) == 0
                    && normalize(other.getManufacturer())
                            .equals(normalize(manufacturer))
                    && normalize(other.getPlaceOfOrigin())
                            .equals(normalize(origin))
                    && Objects.equals(
                            other.getExpirationDate(), expirationDate)
                    && normalize(other.getComments())
                            .equals(normalize(comments))) {

                return "Duplicate item.";
            }
        }

        return null;
    }

    private String normalize(String text) {
        if (text == null) {
            return "";
        }

        return text.trim();
    }

    private void clearInformation() {
        nameField.clear();
        priceField.clear();
        manufacturerField.clear();
        originField.clear();
        commentsField.clear();
        quantityField.clear();
        expirationPicker.setValue(null);
    }

    private void setInformationEditable(boolean editable) {
        nameField.setEditable(editable);
        priceField.setEditable(editable);
        manufacturerField.setEditable(editable);
        originField.setEditable(editable);
        commentsField.setEditable(editable);
        expirationPicker.setDisable(!editable);
    }

    private void returnToMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/view/Menu.fxml"));

            Parent root = loader.load();

            MenuController controller = loader.getController();
            controller.setInventory(inventory);

            Stage stage =
                    (Stage) confirmButton.getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.setTitle("PearlMart - Main Menu");

        } catch (IOException | RuntimeException e) {
            messageLabel.setText(
                    "Goods added, but the main menu could not be opened.");

            e.printStackTrace();
        }
    }
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);

        alert.initOwner(confirmButton.getScene().getWindow());
        alert.setTitle("Error");
        alert.setHeaderText("Addition rejected");
        alert.setContentText(message);

        alert.showAndWait();
    }
    private void showAdditionResult(InventoryItem item) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.initOwner(confirmButton.getScene().getWindow());
        alert.setTitle("Addition Result");
        alert.setHeaderText("Item added or updated successfully.");

        String expiration = "Not specified";

        if (item.getExpirationDate() != null) {
            expiration = item.getExpirationDate().toString();
        }

        alert.setContentText(
                "Item ID: " + item.getItemId()
                + "\nName: " + item.getName()
                + "\nSelling price: " + item.getSellingPrice() + " QR"
                + "\nManufacturer: " + item.getManufacturer()
                + "\nPlace of origin: " + item.getPlaceOfOrigin()
                + "\nComments: " + normalize(item.getComments())
                + "\nExpiration date: " + expiration
                + "\nUpdated stock quantity: " + item.getQuantity()
        );

        alert.showAndWait();
    }
    @FXML
    private void handleMainMenu() {
        returnToMenu();
    }
}