package controller;

import java.util.UUID;



import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.util.Locale;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import model.Inventory;
import model.InventoryItem;
import model.Sale;
import model.SaleLineItem;
import model.SaleStatus;
import java.util.ArrayList;
import model.MovementType;
import model.SalesReceipt;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
public class ProcessSaleController {

    private Inventory inventory;
    private Sale currentSale;
    private InventoryItem checkedItem;
    private SalesReceipt currentReceipt;
    private static final ArrayList<Sale> completedSales = new ArrayList<>();
    private static final ArrayList<Sale> cancelledSales = new ArrayList<>();

    @FXML private TextField taxPercentageField;
    @FXML private TextField discountPercentageField;
    @FXML private TextField subtotalField;
    @FXML private TextField discountAmountField;
    @FXML private TextField taxAmountField;
    @FXML private TextField finalAmountField;

    @FXML private Button calculateAmountButton;
    @FXML private Button cancelTransactionButton;
    @FXML private Button confirmTransactionButton;
    @FXML private TextField saleCodeField;
    @FXML private TextField saleQuantityField;
    @FXML private TextField salePriceField;

    @FXML private Button checkAvailabilityButton;
    @FXML private Button addItemButton;
    @FXML private Button finishButton;
    
    @FXML private TableView<SaleLineItem> receiptTable;

    @FXML private TableColumn<SaleLineItem, String> receiptItemColumn;
    @FXML private TableColumn<SaleLineItem, Integer> receiptQuantityColumn;
    @FXML private TableColumn<SaleLineItem, Double> receiptPriceColumn;
    @FXML private TableColumn<SaleLineItem, Double> receiptTotalColumn;
    @FXML private TextField receiptSubtotalField;
    @FXML private TextField receiptDiscountField;
    @FXML private TextField receiptTaxField;
    @FXML private TextField receiptFinalAmountField;

    @FXML private Button receiptFinishButton;

    public ProcessSaleController() {
    }

    @FXML
    private void initialize() {
    	if (receiptTable != null) {
    	    initializeReceipt();
    	    return;
    	}
    	if (subtotalField != null) {
    	    initializeSummary();
    	    return;
    	}
        salePriceField.setEditable(false);

        // We will enable these in the next step.
        addItemButton.setDisable(true);
        finishButton.setDisable(true);

        saleCodeField.textProperty().addListener(
                (obs, oldValue, newValue) -> clearCheck());

        saleQuantityField.textProperty().addListener(
                (obs, oldValue, newValue) -> clearCheck());
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;

        if (currentSale == null) {
            startSale();
        }
    }

    public void startSale() {
        if (currentSale != null
                && currentSale.getStatus() == SaleStatus.PENDING) {
            return;
        }

        String saleId = UUID.randomUUID().toString();
        currentSale = new Sale(saleId);
        clearCheck();
    }

    private void clearCheck() {
        checkedItem = null;
        salePriceField.clear();
        addItemButton.setDisable(true);
    }

    @FXML
    private void handleCheckAvailability() {
        clearCheck();

        if (inventory == null || currentSale == null) {
            showError("Inventory or sale is not ready.");
            return;
        }

        String code = saleCodeField.getText().trim();

        if (code.isEmpty()) {
            showError("Please enter an item identifier or barcode.");
            return;
        }

        InventoryItem item = inventory.find(code);

        if (item == null) {
            showError("Item not found.");
            return;
        }

        try {
            int quantity = Integer.parseInt(
                    saleQuantityField.getText().trim());

            if (!validateLine(item, quantity)) {
                showError(
                        "Quantity must be positive and within available stock."
                        + "\nCurrent stock: " + item.getQuantity()
                        + "\nAlready in this sale: "
                        + quantityInSale(item));
                return;
            }

            checkedItem = item;

            salePriceField.setText(
                    Double.toString(item.getSellingPrice()));


            addItemButton.setDisable(false);

        } catch (NumberFormatException e) {
            showError("Please enter a valid whole-number quantity.");
        }
    }

    private boolean validateLine(InventoryItem item, int quantity) {
        if (item == null || quantity <= 0) {
            return false;
        }

        long requestedTotal =
                (long) quantityInSale(item) + quantity;

        if (requestedTotal > item.getQuantity()) {
            return false;
        }

        return true;
    }

    private int quantityInSale(InventoryItem item) {
        int total = 0;

        for (SaleLineItem line : currentSale.getLines()) {
            if (line.getItem().getItemId()
                    .equals(item.getItemId())) {
                total += line.getQuantity();
            }
        }

        return total;
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);

        if (subtotalField != null && subtotalField.getScene() != null) {
            alert.initOwner(subtotalField.getScene().getWindow());
        } else {
            alert.initOwner(saleCodeField.getScene().getWindow());
        }

        alert.setTitle("Sale Error");
        alert.setHeaderText("Operation could not be completed");
        alert.setContentText(message);

        alert.showAndWait();
    }

   

   
    @FXML
    private void handleAddItem() {
        if (checkedItem == null || currentSale == null) {
            showError("Please check item availability first.");
            return;
        }

        if (currentSale.getStatus() != SaleStatus.PENDING) {
            showError("This sale is no longer pending.");
            return;
        }

        try {
            int quantity = Integer.parseInt(
                    saleQuantityField.getText().trim());

            // Check again, including quantities already in the sale.
            if (!validateLine(checkedItem, quantity)) {
                showError(
                        "Invalid quantity or insufficient stock."
                        + "\nCurrent stock: " + checkedItem.getQuantity()
                        + "\nAlready in this sale: "
                        + quantityInSale(checkedItem));
                clearCheck();
                return;
            }

            SaleLineItem line =
                    currentSale.addLine(checkedItem, quantity);

            if (line == null) {
                showError("The item could not be added.");
                return;
            }

            saleCodeField.clear();
            saleQuantityField.clear();
            clearCheck();

            finishButton.setDisable(false);
            saleCodeField.requestFocus();

        } catch (NumberFormatException e) {
            showError("Please enter a valid whole-number quantity.");
            clearCheck();
        }
    } 
  
   
    	@FXML
    	private void handleRequestPayable() {
    	    if (currentSale == null || currentSale.getLines().isEmpty()) {
    	        showError("Please add at least one item.");
    	        return;
    	    }

    	    try {
    	        FXMLLoader loader = new FXMLLoader(
    	                getClass().getResource("/view/SaleSummary.fxml"));

    	        // Reuse this controller and the same sale.
    	        loader.setController(this);

    	        Parent root = loader.load();

    	        Stage stage =
    	                (Stage) finishButton.getScene().getWindow();

    	        stage.setScene(new Scene(root));
    	        stage.setTitle("PearlMart - Sale Summary");

    	    } catch (IOException e) {
    	        showError("The sale summary could not be opened.");
    	        e.printStackTrace();
    	    }
    	}
   
   
    	private void initializeSummary() {
    	    subtotalField.setText(
    	            formatAmount(currentSale.calculateSubtotal()));

    	    taxPercentageField.setText(
    	            Double.toString(currentSale.getTAX_RATE() * 100));

    	    discountPercentageField.setText(
    	            Double.toString(currentSale.getDISCOUNT_RATE() * 100));

    	    taxPercentageField.setEditable(false);
    	    discountPercentageField.setEditable(false);

    	    confirmTransactionButton.setDisable(true);
    	    cancelTransactionButton.setDisable(false);
    	}

    private void clearCalculatedAmounts() {
        discountAmountField.clear();
        taxAmountField.clear();
        finalAmountField.clear();
        confirmTransactionButton.setDisable(true);
    }

    private String formatAmount(double amount) {
        return String.format(Locale.US, "%.2f", amount);
    }
    
    @FXML
    private void handleCalculateAmount() {
        clearCalculatedAmounts();

        double total = currentSale.calculatePayableAmount();

        if (!Double.isFinite(total)) {
            showError("The calculated amount is invalid.");
            return;
        }

        subtotalField.setText(formatAmount(currentSale.getSubtotal()));
        discountAmountField.setText(formatAmount(currentSale.getDiscountAmount()));
        taxAmountField.setText(formatAmount(currentSale.getTaxAmount()));
        finalAmountField.setText(formatAmount(total));

        confirmTransactionButton.setDisable(false);
    }
    
    @FXML
    private void handleConfirmTransaction() {
        if (currentSale == null
                || currentSale.getStatus() != SaleStatus.PENDING) {
            showError("There is no pending sale to confirm.");
            return;
        }

        if (finalAmountField.getText().isBlank()) {
            showError("Please calculate the final amount first.");
            return;
        }

        if (!inventory.validateStock(currentSale.getLines())) {
            showError("Insufficient stock. Sale was not completed.");
            return;
        }

        confirmTransactionButton.setDisable(true);

        ArrayList<SaleLineItem> deductedLines = new ArrayList<>();

        try {
            for (SaleLineItem line : currentSale.getLines()) {
                boolean removed = inventory.removeStock(
                        line.getItem(),
                        line.getQuantity(),
                        MovementType.SOLD);

                if (!removed) {
                    throw new IllegalStateException(
                            "Stock deduction failed.");
                }

                deductedLines.add(line);
            }

            currentSale.complete();
            currentReceipt = currentSale.generateReceipt();
            if (currentReceipt == null) {
                throw new IllegalStateException(
                        "Receipt could not be generated.");
            }

        } catch (RuntimeException e) {
            inventory.rollbackDeduction(deductedLines);
            currentSale.setStatus(SaleStatus.PENDING);
            currentReceipt = null;

            confirmTransactionButton.setDisable(false);

            showError(
                    "Sale failed. Deducted quantities were restored.");
            return;
        }
        recordSale(currentSale);
        calculateAmountButton.setDisable(true);
        cancelTransactionButton.setDisable(true);
        taxPercentageField.setEditable(false);
        discountPercentageField.setEditable(false);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initOwner(confirmTransactionButton.getScene().getWindow());
        alert.setTitle("Sale Completed");
        alert.setHeaderText(null);
        alert.setContentText("Transaction completed successfully.");
        alert.showAndWait();
        openReceipt();
    }
    private void initializeReceipt() {
        receiptTable.setEditable(false);

        receiptItemColumn.setCellValueFactory(data ->
                new ReadOnlyStringWrapper(
                        data.getValue().getItem().getName()));

        receiptQuantityColumn.setCellValueFactory(data ->
                new ReadOnlyObjectWrapper<Integer>(
                        data.getValue().getQuantity()));

        receiptPriceColumn.setCellValueFactory(data ->
                new ReadOnlyObjectWrapper<Double>(
                        data.getValue().getUnitPrice()));

        receiptTotalColumn.setCellValueFactory(data ->
                new ReadOnlyObjectWrapper<Double>(
                        data.getValue().getLineAmount()));

        receiptTable.setItems(
                FXCollections.observableArrayList(
                        currentSale.getLines()));

        receiptSubtotalField.setText(
                formatAmount(currentReceipt.getSubtotal()));

        receiptDiscountField.setText(
                formatAmount(currentReceipt.getDiscountAmount()));

        receiptTaxField.setText(
                formatAmount(currentReceipt.getTaxAmount()));

        receiptFinalAmountField.setText(
                formatAmount(currentReceipt.getTotalAmount()));
    }
    private void openReceipt() {
        try {
            Stage stage = (Stage) confirmTransactionButton
                    .getScene().getWindow();

            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/view/Recipt.fxml"));

            loader.setController(this);

            Parent root = loader.load();

            stage.setScene(new Scene(root));
            stage.setTitle("PearlMart - Sale Receipt");

        } catch (IOException | RuntimeException e) {
            showError(
                    "Sale completed, but the receipt could not be opened.");
            e.printStackTrace();
        }
    }
    @FXML
    private void handleCancelTransaction() {
        if (currentSale == null
                || currentSale.getStatus() != SaleStatus.PENDING) {
            showError("Only a pending sale can be cancelled.");
            return;
        }

        currentSale.cancel();
        recordCancelledSale(currentSale);
        confirmTransactionButton.setDisable(true);
        cancelTransactionButton.setDisable(true);
        calculateAmountButton.setDisable(true);

        returnToMenu();
    }
    private void returnToMenu() {
        try {
            Stage stage;

            if (receiptFinishButton != null
                    && receiptFinishButton.getScene() != null
                    && receiptFinishButton.getScene().getWindow() != null) {

                stage = (Stage) receiptFinishButton
                        .getScene().getWindow();
            } else {
                stage = (Stage) cancelTransactionButton
                        .getScene().getWindow();
            }

            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/view/menu.fxml"));

            Parent root = loader.load();

            MenuController controller = loader.getController();
            controller.setInventory(inventory);

            stage.setScene(new Scene(root));
            stage.setTitle("PearlMart - Main Menu");

        
        } catch (IOException | RuntimeException e) {
            e.printStackTrace();
            showError("The main menu could not be opened.");
        }
        }
    
    @FXML
    private void handleReceiptFinish() {
        System.out.println("Receipt Finish clicked");
        returnToMenu();
    }
    private void recordSale(Sale sale) {
        if (sale != null && sale.getStatus() == SaleStatus.COMPLETED
                && !completedSales.contains(sale)) {
            completedSales.add(sale);
        }
    }

    private void recordCancelledSale(Sale sale) {
        if (sale != null && sale.getStatus() == SaleStatus.CANCELLED
                && !cancelledSales.contains(sale)) {
            cancelledSales.add(sale);
        }
    }
}
