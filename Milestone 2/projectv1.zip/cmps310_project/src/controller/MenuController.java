package controller;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Inventory;

public class MenuController {

    private Inventory inventory;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @FXML
    private void openAddGoods(ActionEvent event) throws IOException {
        openPage(event, "/view/AddGoods.fxml");
    }

    @FXML
    private void openProcessSale(ActionEvent event) throws IOException {
        openPage(event, "/view/ProcessSale.fxml");
    }

    @FXML
    private void exitApplication() {
        Platform.exit();
    }

    private void openPage(ActionEvent event, String path)
            throws IOException {

        FXMLLoader loader = new FXMLLoader(
                getClass().getResource(path));

        Parent root = loader.load();

        Object controller = loader.getController();

        if (controller instanceof AddGoodsController) {
            AddGoodsController addGoodsController =
                    (AddGoodsController) controller;

            addGoodsController.setInventory(inventory);
        }
        else if (controller instanceof ProcessSaleController) {
            ProcessSaleController saleController =
                    (ProcessSaleController) controller;

            saleController.setInventory(inventory);
        }

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene().getWindow();

        stage.setScene(new Scene(root));
        stage.show();
    }
   
}

