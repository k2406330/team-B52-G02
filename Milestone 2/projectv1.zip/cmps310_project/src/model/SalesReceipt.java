package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
public class SalesReceipt {
private String receiptId;
private LocalDateTime issueDateTime;
private double subtotal;
private double discountAmount;
private double taxAmount;
private double totalAmount;
private ArrayList<SaleLineItem> lines = new ArrayList<>();
public SalesReceipt(String receiptId, LocalDateTime issueDateTime, double subtotal, double discountAmount,
		double taxAmount, double totalAmount) {
	super();
	this.receiptId = receiptId;
	this.issueDateTime = issueDateTime;
	this.subtotal = subtotal;
	this.discountAmount = discountAmount;
	this.taxAmount = taxAmount;
	this.totalAmount = totalAmount;
}
public void setLines(ArrayList<SaleLineItem> lines) {
    this.lines = new ArrayList<>(lines);
}
public String getReceiptId() {
	return receiptId;
}
public void setReceiptId(String receiptId) {
	this.receiptId = receiptId;
}
public LocalDateTime getIssueDateTime() {
	return issueDateTime;
}
public void setIssueDateTime(LocalDateTime issueDateTime) {
	this.issueDateTime = issueDateTime;
}
public double getSubtotal() {
	return subtotal;
}
public void setSubtotal(double subtotal) {
	this.subtotal = subtotal;
}
public double getDiscountAmount() {
	return discountAmount;
}
public void setDiscountAmount(double discountAmount) {
	this.discountAmount = discountAmount;
}
public double getTaxAmount() {
	return taxAmount;
}
public void setTaxAmount(double taxAmount) {
	this.taxAmount = taxAmount;
}
public double getTotalAmount() {
	return totalAmount;
}
public void setTotalAmount(double totalAmount) {
	this.totalAmount = totalAmount;
}

public String toText() {
    String text = "===== RECEIPT =====\n";

    text += "Receipt ID: " + receiptId + "\n";
    text += "Date: " + issueDateTime + "\n";
    text += "-------------------\n";

    for (SaleLineItem line : lines) {
        text += line.getItem().getName()
                + " x" + line.getQuantity()
                + " @ " + line.getUnitPrice()
                + " = " + line.getLineAmount()
                + " QR\n";
    }

    text += "-------------------\n";
    text += "Subtotal: " + subtotal + " QR\n";
    text += "Discount: " + discountAmount + " QR\n";
    text += "Tax: " + taxAmount + " QR\n";
    text += "Total: " + totalAmount + " QR\n";

    return text;
}
}