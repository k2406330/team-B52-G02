package model;

import java.time.LocalDate;

public class InventoryItem {
private String itemId;
private String barcode;
private String name;
private double sellingPrice;
private int availableQuantity;
private String manufacturer;
private String placeOfOrigin;
private String comments;
private LocalDate expirationDate;



public InventoryItem(String itemId, String barcode, String name, double sellingPrice, int availableQuantity,
		String manufacturer, String placeOfOrigin, String comments, LocalDate expirationDate) {
	super();
	this.itemId = itemId;
	this.barcode = barcode;
	this.name = name;
	this.sellingPrice = sellingPrice;
	this.availableQuantity = availableQuantity;
	this.manufacturer = manufacturer;
	this.placeOfOrigin = placeOfOrigin;
	this.comments = comments;
	this.expirationDate = expirationDate;
}
public String getItemId() {
	return itemId;
}
public void setItemId(String itemId) {
	this.itemId = itemId;
}
public String getBarcode() {
	return barcode;
}
public void setBarcode(String barcode) {
	this.barcode = barcode;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSellingPrice() {
	return sellingPrice;
}
public void setSellingPrice(double sellingPrice) {
	this.sellingPrice = sellingPrice;
}
public int getQuantity() {
	return availableQuantity;
}
public void setQuantity(int quantity) {
	this.availableQuantity = quantity;
}
public String getManufacturer() {
	return manufacturer;
}
public void setManufacturer(String manufacturer) {
	this.manufacturer = manufacturer;
}
public String getPlaceOfOrigin() {
	return placeOfOrigin;
}
public void setPlaceOfOrigin(String placeOfOrigin) {
	this.placeOfOrigin = placeOfOrigin;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
public LocalDate getExpirationDate() {
	return expirationDate;
}
public void setExpirationDate(LocalDate expirationDate) {
	this.expirationDate = expirationDate;
}

public boolean isAvailable (int quantity ) {
	if (this.availableQuantity>0&&this.availableQuantity>=quantity&& quantity>0)
		return true;
	return false;
	
}

public void increaseQuantity(int quantity) {
	if(quantity>0)
	this.availableQuantity+=quantity;
}

public void decreaseQuantity(int quantity) {
	if(quantity>0 && this.availableQuantity>=quantity)
		this.availableQuantity-=quantity;
}
/*
public void updateInfo(InventoryItem updated ) {
	
		this.itemId=updated.getItemId();
		this.barcode=updated.getBarcode();;
		this.name=updated.getName();
		this.sellingPrice=updated.getSellingPrice();
		this.availableQuantity=updated.getQuantity();
	    this.manufacturer=updated.getManufacturer();
	    this.PlaceOfOrigin=updated.getPlaceOfOrigin();
		this.comments=updated.getComments();
		this.expirationDate=updated.getExpirationDate();
}
public boolean isExpired(LocalDate today) {
	if (this.expirationDate==null)  // if there is not expirationDate
		return false;
	if (this.expirationDate.isAfter(today))
		return false;
	return true;		
}
*/
}
