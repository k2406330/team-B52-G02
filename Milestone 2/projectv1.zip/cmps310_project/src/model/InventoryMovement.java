package model;


import java.time.LocalDateTime;

public class InventoryMovement {
private String movementId;
private MovementType type;
private int quantity;
private LocalDateTime dateTime;
private InventoryItem item;

public InventoryMovement(String movementId, MovementType type,
        int quantity, LocalDateTime localDate, InventoryItem item) {
this.movementId = movementId;
this.type = type;
this.quantity = quantity;
this.dateTime = localDate;
this.item = item;
}

public LocalDateTime getDateTime() {
	return dateTime;
}

public void setDateTime(LocalDateTime dateTime) {
	this.dateTime = dateTime;
}

public InventoryItem getItem() {
	return item;
}

public void setItem(InventoryItem item) {
	this.item = item;
}

public String getMovementId() {
	return movementId;
}

public void setMovementId(String movementId) {
	this.movementId = movementId;
}
public MovementType getType() {
	return type;
}
public void setType(MovementType type) {
	this.type = type;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
}