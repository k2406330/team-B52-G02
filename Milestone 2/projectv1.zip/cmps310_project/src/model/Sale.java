package model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Sale {
private String saleId;
private LocalDateTime dateTime;
private SaleStatus status;
private double subtotal;
private double discountAmount;
private double taxAmount;
private double totalAmount;
private double TAX_RATE=0.10;
private double DISCOUNT_RATE=0.10;
private ArrayList<SaleLineItem> lines= new ArrayList<>();
public String getSaleId() {
	return saleId;
}

public Sale(String saleId) {
    this.saleId = saleId;
    this.dateTime = LocalDateTime.now();
    this.status = SaleStatus.PENDING;
}
public LocalDateTime getDateTime() {
	return dateTime;
}


public void setDateTime(LocalDateTime dateTime) {
	this.dateTime = dateTime;
}


public SaleStatus getStatus() {
	return status;
}


public void setStatus(SaleStatus status) {
	this.status = status;
}


public double getSubtotal() {
	return subtotal;
}


public void setSubtotal(double subtotal) {
	this.subtotal = subtotal;
}


public double getDiscountAmount() {
	return discountAmount;
}


public void setDiscountAmount(double discountAmount) {
	this.discountAmount = discountAmount;
}


public double getTaxAmount() {
	return taxAmount;
}


public void setTaxAmount(double taxAmount) {
	this.taxAmount = taxAmount;
}


public double getTotalAmount() {
	return totalAmount;
}


public void setTotalAmount(double totalAmount) {
	this.totalAmount = totalAmount;
}


public double getTAX_RATE() {
	return TAX_RATE;
}


public void setTAX_RATE(double tAX_RATE) {
	TAX_RATE = tAX_RATE;
}


public double getDISCOUNT_RATE() {
	return DISCOUNT_RATE;
}


public void setDISCOUNT_RATE(double dISCOUNT_RATE) {
	DISCOUNT_RATE = dISCOUNT_RATE;
}


public ArrayList<SaleLineItem> getLines() {
	return lines;
}


public void setLines(ArrayList<SaleLineItem> lines) {
	this.lines = lines;
}


public void setSaleId(String saleId) {
	this.saleId = saleId;
}


public SaleLineItem addLine(InventoryItem item, int quantity) {
    if (status != SaleStatus.PENDING || item == null || quantity <= 0) {
        return null;
    }

    SaleLineItem line = new SaleLineItem(item, quantity);
    lines.add(line);
    return line;
}

	
public double calculatePayableAmount() {
    calculateSubtotal();
    applyDiscountAndTax();
    return this.totalAmount;
}
public double calculateSubtotal() {
    double total = 0;

    for (SaleLineItem line : lines) {
        total += line.calculateLineTotal();
    }

    this.subtotal = total;
    return this.subtotal;
}
public boolean applyDiscountAndTax() {
    discountAmount = subtotal * DISCOUNT_RATE;

    double amountAfterDiscount = subtotal - discountAmount;

    taxAmount = amountAfterDiscount * TAX_RATE;
    totalAmount = amountAfterDiscount + taxAmount;

    return true;
}
public void complete() {
    if (status != SaleStatus.PENDING || lines.isEmpty()) {
        return;
    }

    calculatePayableAmount();
    this.status = SaleStatus.COMPLETED;
}
public void cancel() {
    if (status != SaleStatus.PENDING) {
        return;
    }

    this.status = SaleStatus.CANCELLED;
}
public SalesReceipt generateReceipt() {
    if (status != SaleStatus.COMPLETED) {
        return null;
    }

    SalesReceipt receipt = new SalesReceipt(
            "R-" + saleId,
            LocalDateTime.now(),
            subtotal,
            discountAmount,
            taxAmount,
            totalAmount
    );

    receipt.setLines(lines);
    return receipt;
}
}
