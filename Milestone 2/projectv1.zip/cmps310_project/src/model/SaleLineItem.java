package model;

public class SaleLineItem {
private InventoryItem item;
private int quantity;
private double unitPrice;
private double lineAmount;




public SaleLineItem(InventoryItem item, int quantity) {
    this.item = item;
    this.quantity = quantity;
    this.unitPrice = item.getSellingPrice();
    this.lineAmount=calculateLineTotal();
}

public double getLineAmount() {
    return calculateLineTotal();
}

public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public double getUnitPrice() {
	return unitPrice;
}
public void setUnitPrice(double unitPrice) {
	this.unitPrice = unitPrice;
}

public double calculateLineTotal() {
    this.lineAmount = this.quantity * this.unitPrice;
    return this.lineAmount;
}
public InventoryItem getItem() {
	return item;
}
public void setItem(InventoryItem item) {
	this.item = item;
}

}
