package model;

import java.time.LocalDate;

public class CancelledReceipt {
private String cancelld;
private LocalDate date;
public String getCancelld() {
	return cancelld;
}
public void setCancelld(String cancelld) {
	this.cancelld = cancelld;
}
public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}

}
