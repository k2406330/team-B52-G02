package model;

public enum MovementType {
ADDED,
SOLD;

}
