package model;

import java.time.LocalDateTime;
import java.util.UUID;

public class MovementFactory {
	public InventoryMovement createMovement(MovementType type, int quantity, InventoryItem item) {
		if (type == null || item == null || quantity <= 0) {
			return null;
		}
		String prefix;
		if (type == MovementType.ADDED) {
			prefix = "ADD-";
		} else {
			prefix = "SALE-";
		}
		return new InventoryMovement(prefix + UUID.randomUUID(), type, quantity, LocalDateTime.now(), item);
	}
}