package model;

import java.util.ArrayList;

public class SaleFacade {
	private final Inventory inventory;

	public SaleFacade(Inventory inventory) {
		this.inventory = inventory;
	}

	public SalesReceipt confirmSale(Sale sale) {
		if (sale == null || sale.getStatus() != SaleStatus.PENDING)
			return null;
		if (!inventory.validateStock(sale.getLines()))
			return null;

		ArrayList<SaleLineItem> deducted = new ArrayList<>();
		try {
			for (SaleLineItem line : sale.getLines()) {
				if (!inventory.removeStock(line.getItem(), line.getQuantity(), MovementType.SOLD)) {
					throw new IllegalStateException("Stock deduction failed.");
				}
				deducted.add(line);
			}
			sale.complete();
			SalesReceipt receipt = sale.generateReceipt();
			if (receipt == null)
				throw new IllegalStateException("Receipt could not be generated.");
			return receipt;
		} catch (RuntimeException e) {
			inventory.rollbackDeduction(deducted);
			sale.setStatus(SaleStatus.PENDING);
			return null;
		}
	}
}