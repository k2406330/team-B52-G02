package model;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
	private ArrayList<InventoryItem> items;
	private ArrayList<InventoryMovement> movements;
	private final MovementFactory movementFactory = new MovementFactory();

	public Inventory() {
		items = new ArrayList<>();
		movements = new ArrayList<>();
	}

	public InventoryItem find(String code) {
		InventoryItem item = searchByIdentifier(code);

		if (item != null) {
			return item;
		}

		return searchByBarcode(code);
	}

	public InventoryItem searchByIdentifier(String itemid) {
		for (InventoryItem i : items) {
			if (i.getItemId().equals(itemid))
				return i;
		}
		return null;
	}

	public InventoryItem searchByBarcode(String barcode) {
		for (InventoryItem i : items) {
			if (i.getBarcode().equals(barcode))
				return i;
		}
		return null;
	}

	public ArrayList<InventoryItem> searchByName(String name) {
		ArrayList<InventoryItem> i = new ArrayList<>();
		for (InventoryItem item : items) {
			if (item.getName().equals(name))
				i.add(item);

		}
		return i;
	}

	public void add(InventoryItem item) {
		if (item != null && searchByIdentifier(item.getItemId()) == null)
			items.add(item);

	}

	public void addMovement(InventoryMovement movement) {
		if (movement != null) {
			movements.add(movement);
		}
	}

	public void addStock(InventoryItem item, int quantity) {
		if (item != null && searchByIdentifier(item.getItemId()) != null && quantity > 0) {
			InventoryItem i = searchByIdentifier(item.getItemId());
			i.increaseQuantity(quantity);
			recordMovement(i, quantity, MovementType.ADDED);
		}
	}

	public boolean removeStock(InventoryItem item, int quantity, MovementType type) {
		if (item != null && searchByIdentifier(item.getItemId()) != null && quantity > 0) {
			InventoryItem i = searchByIdentifier(item.getItemId());
			if (i.isAvailable(quantity)) {
				i.decreaseQuantity(quantity);
				recordMovement(i, quantity, type);
				return true;
			}
		}

		return false;
	}

	private InventoryMovement recordMovement(InventoryItem item, int Quantity, MovementType type) {
		InventoryMovement movement = movementFactory.createMovement(type, Quantity, item);
		if (movement != null)
			movements.add(movement);
		return movement;
	}

	public boolean validateStock(List<SaleLineItem> lines) {
		if (lines == null || lines.isEmpty()) {
			return false;
		}

		for (SaleLineItem line : lines) {
			if (line == null || line.getItem() == null || line.getQuantity() <= 0) {
				return false;
			}

			InventoryItem item = searchByIdentifier(line.getItem().getItemId());

			if (item == null) {
				return false;
			}

			long totalQuantity = 0;

			for (SaleLineItem other : lines) {
				if (other == null || other.getItem() == null || other.getQuantity() <= 0) {
					return false;
				}

				if (item.getItemId().equals(other.getItem().getItemId())) {
					totalQuantity += other.getQuantity();
				}
			}

			if (totalQuantity > item.getQuantity()) {
				return false;
			}
		}

		return true;
	}

	public void rollbackDeduction(List<SaleLineItem> lines) {
		if (lines == null) {
			return;
		}

		for (SaleLineItem line : lines) {
			if (line != null && line.getItem() != null && line.getQuantity() > 0) {

				InventoryItem item = searchByIdentifier(line.getItem().getItemId());

				if (item != null) {
					item.increaseQuantity(line.getQuantity());
				}
			}
		}
	}
}
